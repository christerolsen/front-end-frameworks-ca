// /src/constant/api.js

export const baseUrl = "https://v2.api.noroff.dev/online-shop/";
