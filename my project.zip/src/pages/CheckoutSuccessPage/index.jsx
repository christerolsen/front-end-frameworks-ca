// /src/pages/CheckoutSuccessPage/index.jsx

const CheckoutSuccessPage = () => {
  document.title = "Success | eComify";

  return (
    <>
      <h1>Checkout Succsess H1</h1>
      <p>Main is where the main content of the page will diplay</p>
      <h2>And here's H2</h2>
      <p>
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Rem quaerat,
        temporibus doloribus voluptatum consectetur iste optio quam? Non ipsa
        saepe quasi, temporibus eveniet ullam ipsum sint molestiae amet,
        doloremque quae.
      </p>
      <h3>Where this is H3</h3>
      <p>
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Rem quaerat,
        temporibus doloribus voluptatum consectetur iste optio quam? Non ipsa
        saepe quasi, temporibus eveniet ullam ipsum sint molestiae amet,
        doloremque quae.
      </p>
      <p>
        <a href="#">This is a link</a>
      </p>
      <button>Click</button>
    </>
  );
};

export default CheckoutSuccessPage;
