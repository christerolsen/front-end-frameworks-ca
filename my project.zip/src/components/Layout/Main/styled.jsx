// /src/components/Layout/Main/styled.jsx

import styled from "styled-components";

export const StyledMain = styled.main`
  padding: 5%;
  padding-top: 40px;
  overflow: auto;
`;
