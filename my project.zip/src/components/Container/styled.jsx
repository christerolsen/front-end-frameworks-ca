// /src/components/Container/styled.jsx

import styled from "styled-components";

export const StyledContainer = styled.div`
  max-width: 1000px;
  margin-inline: auto;
`;
